package com.group7.mezat.documents;

public enum Status {
    SOLD, UNSOLD
}
