package com.group7.mezat.documents;

public enum Role {
    BIDDER, ADMIN, COOPERATIVE
}
