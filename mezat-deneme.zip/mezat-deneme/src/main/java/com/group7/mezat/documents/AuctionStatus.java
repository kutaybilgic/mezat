package com.group7.mezat.documents;

public enum AuctionStatus {
    STARTING,CANCELED,OPEN,FINISHED
}
