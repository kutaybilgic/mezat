package com.group7.mezat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MezatApplicationTests {

	@Test
	void contextLoads() {
	}

}
